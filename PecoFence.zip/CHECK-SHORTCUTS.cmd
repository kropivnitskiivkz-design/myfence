@echo off
setlocal
cd /d "%~dp0"
cargo test -p pecofence-core shortcut_store::tests
if errorlevel 1 exit /b 1
cargo test -p pecofence --bin pecofence state::shortcuts::tests
if errorlevel 1 exit /b 1
cargo build --release -p pecofence
if errorlevel 1 exit /b 1
endlocal
