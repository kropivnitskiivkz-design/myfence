//! Integrates recoverable shortcut storage with the desktop catalog and memberships.
use super::*;
use pecofence_core::shortcut_store::{ShortcutStore, StoredShortcut, is_shortcut};
use pecofence_platform::shortcut_move::move_no_replace;
use std::io;

impl AppState {
    pub fn shortcut_directory(&self) -> PathBuf { self.store.dir().join("shortcuts") }
    fn shortcut_store(&self) -> ShortcutStore { ShortcutStore::new(self.shortcut_directory()) }

    fn is_managed_shortcut_path(&self, path: &Path) -> bool {
        let key = ItemKey::from_path(&path.to_string_lossy());
        let root = ItemKey::from_path(&self.shortcut_directory().to_string_lossy());
        match (key.as_path(), root.as_path()) {
            (Some(path), Some(root)) => Path::new(path).starts_with(root),
            _ => false,
        }
    }


    pub(super) fn shortcut_problem(&mut self, message: String) {
        tracing::warn!(%message, "shortcut storage");
        if !self.shortcut_errors.contains(&message) { self.shortcut_errors.push(message); }
    }

    pub fn take_shortcut_errors(&mut self) -> Vec<String> {
        std::mem::take(&mut self.shortcut_errors)
    }

    fn shortcut_records(&mut self) -> Vec<StoredShortcut> {
        let store = self.shortcut_store();
        let Ok(entries) = std::fs::read_dir(store.root()) else { return Vec::new(); };
        let mut records = Vec::new();
        for entry in entries.flatten() {
            let Ok(item) = entry.file_name().to_string_lossy().parse::<ItemId>() else { continue; };
            match store.record(item) {
                Ok(Some(record)) => records.push(record),
                Ok(None) => {},
                Err(error) => self.shortcut_problem(format!("Не вдалося прочитати запис ярлика {item}: {error}")),
            }
        }
        records
    }

    pub fn desktop_entries_with_shortcuts(&mut self) -> Vec<DesktopEntry> {
        let mut entries = shell::enumerate_desktop();
        for entry in self.managed_shortcut_entries() {
            let key = ItemKey::from_path(&entry.path.to_string_lossy());
            if !entries.iter().any(|e| ItemKey::from_path(&e.path.to_string_lossy()) == key) {
                entries.push(entry);
            }
        }
        entries
    }

    /// Reconnects journalled paths before desktop reconciliation can orphan the old paths.
    /// Also recovers the original item id if config saving was interrupted after the move.
    pub(super) fn managed_shortcut_entries(&mut self) -> Vec<DesktopEntry> {
        let mut entries = Vec::new();
        for record in self.shortcut_records() {
            let Some(path) = record.live_path().map(Path::to_path_buf) else { continue; };
            let origin = if shell::public_desktop().zip(record.original.parent()).is_some_and(|(dir, parent)| ItemKey::from_path(&dir.to_string_lossy()) == ItemKey::from_path(&parent.to_string_lossy())) {
                EntryOrigin::PublicDesktop
            } else { EntryOrigin::UserDesktop };
            let Some(entry) = shell::stat_entry(&path, origin) else { continue; };
            let old = self.config.items.get(&record.item)
                .and_then(|item| item.key.as_path().map(PathBuf::from));
            if let Some(old) = old {
                if ItemKey::from_path(&old.to_string_lossy()) != ItemKey::from_path(&path.to_string_lossy()) {
                    self.rename_item(&old, &path);
                }
            } else {
                let key = ItemKey::from_path(&path.to_string_lossy());
                let (icon_key, _) = crate::icons::icon_key_for(&path, false, entry.mtime);
                self.config.items.insert(record.item, Item {
                    id: record.item, key: key.clone(),
                    origin: if origin == EntryOrigin::PublicDesktop { Origin::PublicDesktop } else { Origin::UserDesktop },
                    display_name: shell::display_name(&path).unwrap_or_else(|| entry.file_name.clone()),
                    file_id: None, mtime: entry.mtime, is_folder: false, attrs: entry.attributes,
                    icon_key, orphaned_since: None, size: entry.size, open_count: 0, last_opened: None,
                });
                self.catalog.insert(key, record.item);
                self.dirty = true;
            }
            if record.stored.is_none() && (record.committed || record.returning.as_deref() == Some(path.as_path())) {
                // Returning was journalled before a crash: do not re-park it in the old fence.
                if let Some(inbox) = self.inbox_id() {
                    self.config.assign(self.layout, record.item, inbox, AssignedBy::User);
                }
                self.dirty = true;
            }
            if record.stored.is_some() && !self.is_managed_shortcut_path(&path) {
                self.shortcut_problem(format!("Переміщення «{}» не завершене. Оригінал залишився на робочому столі; обидва файли збережено.", entry.file_name));
            }
            entries.push(entry);
        }
        entries
    }

    /// Only direct desktop .lnk/.url files are parked; folders and documents stay put.
    pub(super) fn prepare_shortcut_for_fence(&mut self, id: ItemId, to: FenceId) -> io::Result<bool> {
        let Some(kind) = self.fence(to).map(|f| f.kind) else { return Ok(false); };
        if kind == FenceKind::FolderPortal { return Ok(false); }
        let Some((item_path, is_folder)) = self.config.items.get(&id).and_then(|item| {
            item.key.as_path().map(|path| (PathBuf::from(path), item.is_folder))
        }) else { return Ok(false); };
        let path = item_path;
        let managed = self.is_managed_shortcut_path(&path);
        if (kind == FenceKind::Inbox && !managed) || (kind != FenceKind::Inbox && managed) {
            return Ok(false);
        }
        let store = self.shortcut_store();
        let record = store.record(id)?;
        let next = if kind == FenceKind::Inbox {
            if !managed { return Ok(false); }
            store.restore(id, move_no_replace)?
        } else {
            if managed || is_folder || !is_shortcut(&path) || !path.is_file() { return Ok(false); }
            let on_desktop = [shell::user_desktop(), shell::public_desktop()].into_iter().flatten()
                .any(|dir| path.parent().is_some_and(|p| ItemKey::from_path(&p.to_string_lossy()) == ItemKey::from_path(&dir.to_string_lossy())));
            if !on_desktop { return Ok(false); }
            if let Some(record) = record {
                if record.stored.is_none() {
                    // Aborted park / previously completed return. Preserve config first.
                    self.dirty = true;
                    if !self.save_if_dirty() { return Err(io::Error::other("Не вдалося зберегти конфігурацію")); }
                    // save_if_dirty normally cleans this record after saving the live path.
                    if store.record(id)?.is_some() { store.finish_return(id)?; }
                } else {
                    return Err(io::Error::other("Попереднє переміщення ярлика не завершене"));
                }
            }
            // ItemKey is lower-cased. Preserve the real filename's spelling when parking.
            let actual = path.parent().and_then(|parent| std::fs::read_dir(parent).ok())
                .and_then(|entries| entries.flatten().map(|e| e.path()).find(|p|
                    ItemKey::from_path(&p.to_string_lossy()) == ItemKey::from_path(&path.to_string_lossy())))
                .unwrap_or_else(|| path.clone());
            Some(store.park(id, &actual, move_no_replace)?)
        };
        if let Some(next) = next {
            let changed = self.rename_item(&path, &next);
            self.dirty |= changed;
            return Ok(changed);
        }
        Ok(false)
    }

    /// Handles existing panels on upgrade and membership changes made by rules/layouts.
    pub fn reconcile_shortcut_storage(&mut self) -> usize {
        let shortcut_root = ItemKey::from_path(&self.shortcut_directory().to_string_lossy());
        let inbox = self.inbox_id();
        let plan: Vec<_> = self.config.items.values().filter_map(|item| {
            if self.shortcut_failures.contains(&item.id) { return None; }
            let path = item.key.as_path()?;
            let path_obj = Path::new(path);
            let managed = match (ItemKey::from_path(path), shortcut_root.as_path()) {
                (Some(path), Some(root)) => Path::new(path).starts_with(root),
                _ => false,
            };
            if !is_shortcut(path_obj) && !managed { return None; }
            let to = self.config.fence_of_item(self.layout, item.id).or(inbox)?;
            Some((item.id, to))
        }).collect();
        let mut changed = 0;
        for (id, to) in plan {
            match self.prepare_shortcut_for_fence(id, to) {
                Ok(true) => changed += 1,
                Ok(false) => {},
                Err(error) => {
                    // A failed transfer emits filesystem events too. Do not loop on retries.
                    self.shortcut_failures.insert(id);
                    self.shortcut_problem(format!("Не вдалося перемістити ярлик {id}: {error}"));
                },
            }
        }
        if self.dirty { self.save_if_dirty(); }
        changed
    }

    pub(super) fn finish_shortcut_returns(&mut self) {
        let store = self.shortcut_store();
        for record in self.shortcut_records() {
            if record.stored.is_some() { continue; }
            let Some(live) = record.live_path() else { continue; };
            if self.config.items.get(&record.item).is_some_and(|item|
                item.key == ItemKey::from_path(&live.to_string_lossy())) {
                if let Err(error) = store.finish_return(record.item) {
                    tracing::warn!(%error, "shortcut journal cleanup deferred");
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stored_shortcut_survives_sync_and_panel_deletion_restores_it() {
        let mut state = super::super::tests::test_state();
        let root = std::env::temp_dir().join(format!("pecofence-shortcut-state-{}", ItemId::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        state.store = ConfigStore::new(root.join("config"));
        let original = root.join("Test.url");
        std::fs::write(&original, b"[InternetShortcut]\r\nURL=https://example.com\r\n").unwrap();
        let panel = state.new_fence("Test", RECT { left: 0, top: 0, right: 300, bottom: 200 }).unwrap();
        let entry = shell::stat_entry(&original, EntryOrigin::UserDesktop).unwrap();
        state.sync_desktop(&[entry]);
        let item = state.item_by_path(&original).unwrap();
        state.config.assign(state.layout, item, panel, AssignedBy::User);
        let stored = state.shortcut_store().park(item, &original, move_no_replace).unwrap();
        // Simulate a crash after moving but before saving/re-keying the catalog.
        state.sync_desktop(&[]);
        assert_eq!(state.item_by_path(&stored), Some(item));
        assert_eq!(state.config.fence_of_item(state.layout, item), Some(panel));
        assert!(state.item(item).unwrap().orphaned_since.is_none());
        assert!(state.delete_fence(panel));
        assert!(original.exists()); assert!(!stored.exists());
        assert_eq!(state.item_by_path(&original), Some(item));
        state.save_if_dirty();
        assert!(state.shortcut_store().record(item).unwrap().is_none());
        let _ = std::fs::remove_dir_all(root);
    }
}
