//! Recoverable storage of desktop shortcut files. Targets are never opened or moved.
//! Each item has an immutable origin record, a data directory, and a return intent.
//! The caller supplies a no-replace filesystem move and saves item paths before cleanup.
use crate::ItemId;
use serde::{Deserialize, Serialize};
use std::fs::{self, OpenOptions};
use std::io::{self, Write};
use std::path::{Path, PathBuf};

#[derive(Debug, Serialize, Deserialize)]
struct OriginRecord {
    item: ItemId,
    original: PathBuf,
}

#[derive(Debug)]
pub struct StoredShortcut {
    pub item: ItemId,
    pub original: PathBuf,
    pub stored: Option<PathBuf>,
    pub returning: Option<PathBuf>,
    pub committed: bool,
}

impl StoredShortcut {
    /// A recreated desktop shortcut must not steal the identity of a parked one.
    pub fn live_path(&self) -> Option<&Path> {
        if let Some(stored) = &self.stored {
            if self.committed || !self.original.exists() {
                return Some(stored);
            }
            // Interrupted cross-volume copy: preserve both files, keep using the source.
            return Some(&self.original);
        }
        self.returning.as_deref().filter(|p| p.is_file())
            .or_else(|| self.original.is_file().then_some(self.original.as_path()))
    }
}

pub struct ShortcutStore {
    root: PathBuf,
}

pub fn is_shortcut(path: &Path) -> bool {
    path.extension().and_then(|s| s.to_str())
        .is_some_and(|s| s.eq_ignore_ascii_case("lnk") || s.eq_ignore_ascii_case("url"))
}

fn write_new<T: Serialize>(path: &Path, value: &T) -> io::Result<()> {
    let bytes = serde_json::to_vec(value).map_err(io::Error::other)?;
    let mut file = OpenOptions::new().write(true).create_new(true).open(path)?;
    file.write_all(&bytes)?;
    file.sync_all()
}

fn read_json<T: serde::de::DeserializeOwned>(path: &Path) -> io::Result<T> {
    serde_json::from_slice(&fs::read(path)?).map_err(io::Error::other)
}

impl ShortcutStore {
    pub fn new(root: PathBuf) -> Self { Self { root } }
    pub fn root(&self) -> &Path { &self.root }
    fn directory(&self, item: ItemId) -> PathBuf { self.root.join(item.to_string()) }

    pub fn record(&self, item: ItemId) -> io::Result<Option<StoredShortcut>> {
        let dir = self.directory(item);
        if !dir.exists() { return Ok(None); }
        let origin: OriginRecord = read_json(&dir.join("origin.json"))?;
        if origin.item != item { return Err(io::Error::other("Shortcut identity mismatch")); }
        let mut files = Vec::new();
        if dir.join("data").exists() {
            for entry in fs::read_dir(dir.join("data"))? {
                let entry = entry?;
                if entry.file_type()?.is_file() { files.push(entry.path()); }
            }
        }
        if files.len() > 1 { return Err(io::Error::other("Multiple files in shortcut storage; preserved for recovery")); }
        let intent = dir.join("return.json");
        let returning = if intent.exists() { Some(read_json(&intent)?) } else { None };
        Ok(Some(StoredShortcut { item, original: origin.original, stored: files.pop(),
            returning, committed: dir.join("parked.json").exists() }))
    }

    pub fn records(&self) -> io::Result<Vec<StoredShortcut>> {
        let mut out = Vec::new();
        if !self.root.exists() { return Ok(out); }
        for entry in fs::read_dir(&self.root)? {
            let entry = entry?;
            if !entry.file_type()?.is_dir() { continue; }
            let Ok(id) = entry.file_name().to_string_lossy().parse::<ItemId>() else { continue; };
            if let Some(record) = self.record(id)? { out.push(record); }
        }
        Ok(out)
    }

    pub fn park(&self, item: ItemId, source: &Path,
        move_file: impl Fn(&Path, &Path) -> io::Result<()>) -> io::Result<PathBuf> {
        if !is_shortcut(source) || !fs::symlink_metadata(source)?.file_type().is_file() {
            return Err(io::Error::other("Only regular .lnk and .url files can be stored"));
        }
        let dir = self.directory(item);
        if dir.exists() {
            return Err(io::Error::other("A previous shortcut transfer requires recovery"));
        }
        fs::create_dir_all(dir.join("data"))?;
        write_new(&dir.join("origin.json"), &OriginRecord { item, original: source.to_path_buf() })?;
        let dest = dir.join("data").join(source.file_name().ok_or_else(|| io::Error::other("No shortcut name"))?);
        move_file(source, &dest)?;
        if source.exists() { return Err(io::Error::other("Shortcut was copied but could not be removed from the desktop")); }
        // Source already moved: the origin journal recovers it even if this marker fails.
        let _ = write_new(&dir.join("parked.json"), &true);
        Ok(dest)
    }

    pub fn restore(&self, item: ItemId,
        move_file: impl Fn(&Path, &Path) -> io::Result<()>) -> io::Result<Option<PathBuf>> {
        let Some(record) = self.record(item)? else { return Ok(None); };
        let Some(source) = record.stored else {
            return Ok(record.returning.filter(|p| p.is_file())
                .or_else(|| record.original.is_file().then_some(record.original)));
        };
        let parent = record.original.parent().ok_or_else(|| io::Error::other("No original desktop directory"))?;
        // Do not manufacture a missing/offline redirected Desktop directory.
        if !parent.is_dir() { return Err(io::Error::other("The original desktop directory is unavailable")); }
        let name = source.file_name().ok_or_else(|| io::Error::other("No shortcut name"))?;
        let desired = parent.join(name);
        let intent = self.directory(item).join("return.json");
        for number in 0..10000 {
            let target = if number == 0 { desired.clone() } else {
                let stem = desired.file_stem().unwrap_or_default().to_string_lossy();
                let ext = desired.extension().map(|s| format!(".{}", s.to_string_lossy())).unwrap_or_default();
                parent.join(format!("{stem} (PecoFence {number}){ext}"))
            };
            if target.exists() { continue; }
            if intent.exists() { fs::remove_file(&intent)?; }
            write_new(&intent, &target)?;
            match move_file(&source, &target) {
                Ok(()) => {
                    if source.exists() { return Err(io::Error::other("Shortcut return could not remove the stored file")); }
                    return Ok(Some(target));
                }
                Err(e) if e.kind() == io::ErrorKind::AlreadyExists => continue,
                Err(e) => return Err(e),
            }
        }
        Err(io::Error::other("No free shortcut name on the desktop"))
    }

    /// Called only after the updated application configuration is durable.
    /// Never removes shortcut data, even if a previous move only copied it.
    pub fn finish_return(&self, item: ItemId) -> io::Result<()> {
        let dir = self.directory(item);
        let data = dir.join("data");
        if data.exists() { fs::remove_dir(&data)?; } // fails if any data remains
        for name in ["return.json", "parked.json", "origin.json"] {
            let path = dir.join(name);
            if path.exists() { fs::remove_file(path)?; }
        }
        fs::remove_dir(dir)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    struct Fixture(PathBuf);
    impl Fixture {
        fn new() -> Self {
            let root = std::env::temp_dir().join(format!("pecofence-shortcuts-{}", ItemId::new_v4()));
            fs::create_dir_all(root.join("desktop")).unwrap(); Self(root)
        }
        fn store(&self) -> ShortcutStore { ShortcutStore::new(self.0.join("store")) }
        fn shortcut(&self, name: &str, bytes: &[u8]) -> PathBuf {
            let path = self.0.join("desktop").join(name); fs::write(&path, bytes).unwrap(); path
        }
    }
    impl Drop for Fixture { fn drop(&mut self) { let _ = fs::remove_dir_all(&self.0); } }
    fn move_file(a: &Path, b: &Path) -> io::Result<()> {
        fs::hard_link(a, b)?; fs::remove_file(a)
    }
    #[test]
    fn round_trip_keeps_bytes_and_unassigned_shortcuts() {
        let f=Fixture::new(); let store=f.store(); let id=ItemId::new_v4();
        let source=f.shortcut("Слід.lnk", b"shortcut target stays unchanged");
        let other=f.shortcut("Other.lnk", b"other");
        let stored=store.park(id,&source,move_file).unwrap();
        assert!(!source.exists()); assert!(other.exists());
        assert_eq!(fs::read(&stored).unwrap(),b"shortcut target stays unchanged");
        let returned=store.restore(id,move_file).unwrap().unwrap();
        assert_eq!(returned,source); assert!(!stored.exists());
        assert_eq!(store.record(id).unwrap().unwrap().live_path(),Some(source.as_path()));
        store.finish_return(id).unwrap(); assert!(store.records().unwrap().is_empty());
    }
    #[test]
    fn restore_collision_preserves_both_files() {
        let f=Fixture::new(); let id=ItemId::new_v4(); let store=f.store();
        let source=f.shortcut("Browser.url",b"original");
        store.park(id,&source,move_file).unwrap(); fs::write(&source,b"new desktop link").unwrap();
        let returned=store.restore(id,move_file).unwrap().unwrap();
        assert_ne!(source,returned); assert_eq!(fs::read(source).unwrap(),b"new desktop link");
        assert_eq!(fs::read(returned).unwrap(),b"original");
    }
    #[test]
    fn interrupted_move_and_return_are_recovered_from_journal() {
        let f=Fixture::new(); let id=ItemId::new_v4(); let store=f.store();
        let source=f.shortcut("A.lnk",b"data");
        let stored=store.park(id,&source,move_file).unwrap();
        fs::remove_file(store.directory(id).join("parked.json")).unwrap();
        assert_eq!(f.store().record(id).unwrap().unwrap().live_path(),Some(stored.as_path()));
        let returned=store.restore(id,move_file).unwrap().unwrap();
        assert_eq!(f.store().record(id).unwrap().unwrap().live_path(),Some(returned.as_path()));
    }
    #[test]
    fn denied_move_preserves_source_and_retry_is_possible_after_cleanup() {
        let f=Fixture::new(); let id=ItemId::new_v4(); let store=f.store();
        let source=f.shortcut("A.lnk",b"data");
        assert!(store.park(id,&source,|_,_| Err(io::Error::from(io::ErrorKind::PermissionDenied))).is_err());
        assert_eq!(store.record(id).unwrap().unwrap().live_path(),Some(source.as_path()));
        store.finish_return(id).unwrap(); assert!(source.exists());
        assert!(store.park(id,&source,move_file).is_ok());
    }
    #[test]
    fn renamed_shortcut_returns_with_its_new_name() {
        let f=Fixture::new(); let id=ItemId::new_v4(); let store=f.store();
        let source=f.shortcut("A.lnk",b"data"); let stored=store.park(id,&source,move_file).unwrap();
        fs::rename(&stored,stored.with_file_name("B.lnk")).unwrap();
        let returned=store.restore(id,move_file).unwrap().unwrap();
        assert_eq!(returned.file_name().unwrap(),"B.lnk"); assert_eq!(fs::read(returned).unwrap(),b"data");
    }
    #[test]
    fn partial_copy_never_deletes_either_file() {
        let f=Fixture::new(); let id=ItemId::new_v4(); let store=f.store();
        let source=f.shortcut("A.lnk",b"data");
        assert!(store.park(id,&source,|a,b|fs::copy(a,b).map(|_|())).is_err());
        assert_eq!(store.record(id).unwrap().unwrap().live_path(),Some(source.as_path()));
        assert!(store.finish_return(id).is_err()); assert!(source.exists());
        assert!(store.record(id).unwrap().unwrap().stored.unwrap().exists());
    }
    #[test]
    fn normal_files_are_not_managed() {
        let f=Fixture::new(); let source=f.shortcut("Report.docx",b"document");
        assert!(f.store().park(ItemId::new_v4(),&source,move_file).is_err()); assert!(source.exists());
    }
    #[test]
    fn equal_names_have_separate_storage_and_targets_stay_untouched() {
        let f = Fixture::new(); let store = f.store();
        let a = f.shortcut("Same.lnk", b"first");
        let target = f.0.join("application.exe"); fs::write(&target, b"program").unwrap();
        let one = store.park(ItemId::new_v4(), &a, move_file).unwrap();
        let b = f.shortcut("Same.lnk", b"second");
        let two = store.park(ItemId::new_v4(), &b, move_file).unwrap();
        assert_ne!(one, two); assert_eq!(fs::read(one).unwrap(), b"first");
        assert_eq!(fs::read(two).unwrap(), b"second");
        assert_eq!(fs::read(target).unwrap(), b"program");
    }
    #[test]
    fn failed_return_keeps_stored_shortcut_and_journal_for_retry() {
        let f = Fixture::new(); let store = f.store(); let id = ItemId::new_v4();
        let source = f.shortcut("A.lnk", b"data");
        let stored = store.park(id, &source, move_file).unwrap();
        assert!(store.restore(id, |_, _| Err(io::Error::from(io::ErrorKind::PermissionDenied))).is_err());
        assert!(stored.exists()); assert!(!source.exists());
        assert!(store.finish_return(id).is_err());
        assert_eq!(store.restore(id, move_file).unwrap(), Some(source));
    }

}
