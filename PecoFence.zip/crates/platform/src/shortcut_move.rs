//! Small, non-overwriting moves used by the journalled shortcut store.
use std::io;
use std::os::windows::ffi::OsStrExt;
use std::path::Path;

#[link(name = "kernel32")]
unsafe extern "system" {
    fn MoveFileExW(existing: *const u16, new: *const u16, flags: u32) -> i32;
}

/// Does not replace a destination. Cross-volume moves are allowed for redirected desktops.
/// No shortcut target is resolved: only the .lnk/.url file itself is moved.
pub fn move_no_replace(source: &Path, target: &Path) -> io::Result<()> {
    let a: Vec<u16> = source.as_os_str().encode_wide().chain(Some(0)).collect();
    let b: Vec<u16> = target.as_os_str().encode_wide().chain(Some(0)).collect();
    // MOVEFILE_COPY_ALLOWED | MOVEFILE_WRITE_THROUGH. REPLACE_EXISTING is never set.
    // SAFETY: both buffers are NUL-terminated and live until the synchronous call returns.
    if unsafe { MoveFileExW(a.as_ptr(), b.as_ptr(), 0x2 | 0x8) } == 0 {
        return Err(io::Error::last_os_error());
    }
    // Windows can report success after copying if deletion of the source failed.
    if source.exists() {
        return Err(io::Error::new(io::ErrorKind::PermissionDenied,
            "The shortcut was copied but the original could not be removed"));
    }
    Ok(())
}
