# Documentation

- [Let your AI agent configure PecoFence: quick start and examples](CLI.md#start-with-your-ai-agent)
- [Upgrading to PecoFence](UPGRADING.md)
- [Development and verification](DEVELOPMENT.md)
- [Languages and translation contributions](LOCALIZATION.md)
- [Preparing and publishing a release](RELEASING.md)
- [Portable edition instructions](PORTABLE.md)
- [Command-line control for terminals and AI agents](CLI.md)
- [Product website: build and publishing](WEBSITE.md)
- [Complete feature list, in Chinese](FEATURES.md)
- [README in other languages](readme/) — the root README is English; translations live in `docs/readme/`

The development checkout may retain historical design proposals and implementation
reports under `history/`. These local archives are excluded from public source
exports. Current behavior is documented above and in the source.
